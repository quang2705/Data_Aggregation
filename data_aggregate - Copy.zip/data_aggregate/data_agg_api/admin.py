from django.contrib import admin
from data_agg_api.models import Temperature
# Register your models here.
admin.site.register(Temperature)
