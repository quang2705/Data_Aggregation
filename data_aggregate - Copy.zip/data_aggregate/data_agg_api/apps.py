from django.apps import AppConfig


class DataAggApiConfig(AppConfig):
    name = 'data_agg_api'
